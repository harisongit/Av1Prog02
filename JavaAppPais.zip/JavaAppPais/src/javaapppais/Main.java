
package javaapppais;


public class Main {

    public static void main(String[] args) {
    //instanciar o objeto pais
    Pais brasil = new Pais();
    brasil.setNome("BRASIL");
    brasil.setCapital("Brasilia-DF");
    brasil.setTamanho("8.511.000");
    brasil.setFronteira("Argentina,Bolivia,Colombia,Guiana,Suriname,Venezuela");
    
    //imprimir o objeto pais 
        System.out.println(brasil.getNome());
        System.out.println(brasil.getCapital());
        System.out.println(brasil.getTamanho()+"km2");
        System.out.println("Fronteira com o Brasil : \n"+brasil.getFronteira());
    }
    
}
