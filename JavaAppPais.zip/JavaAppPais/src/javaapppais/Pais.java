
package javaapppais;

public class Pais {
    private String nome;
    private String capital;
    private String tamanho;
    private String fronteira;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getFronteira() {
        return fronteira;
    }

    public void setFronteira(String fronteira) {
        this.fronteira = fronteira;
    }

              
}
